function valt(){
    var nev = document.getElementById('neve').value;
    var cim = document.getElementById('cime').value;
    var tel = document.getElementById('telefonsz').value;
    document.getElementById("valtnev").innerHTML=nev;
    document.getElementById("valtcim").innerHTML=cim;
    document.getElementById("valttel").innerHTML=tel;
}

